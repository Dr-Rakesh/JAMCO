# main.py
import os
import uuid
import asyncio
import shutil
from typing import List, Optional
from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn

import backend  # your backend.py with process_pdf_query

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
UPLOADS_DIR = os.path.join(STATIC_DIR, "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)

app = FastAPI(title="PDF Multimodal RAG API (with static UI)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve /static/... from the static folder
if os.path.isdir(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
else:
    os.makedirs(STATIC_DIR, exist_ok=True)
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Serve index.html at root
@app.get("/", response_class=FileResponse)
async def root():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.isfile(index_path):
        return FileResponse(index_path, media_type="text/html")
    return JSONResponse(status_code=404, content={"error": "index.html not found in static/ directory."})


# Helper to save UploadFile to uploads dir with unique name
def _save_uploadfile(upload_file: UploadFile) -> dict:
    ext = os.path.splitext(upload_file.filename)[1]
    unique_name = f"{uuid.uuid4().hex}{ext}"
    dest_path = os.path.join(UPLOADS_DIR, unique_name)
    with open(dest_path, "wb") as out_file:
        shutil.copyfileobj(upload_file.file, out_file)
    size = os.path.getsize(dest_path)
    return {
        "id": unique_name,  # frontend stores/uses this id
        "name": upload_file.filename,
        "size": size,
        "type": upload_file.content_type,
        "url": f"/static/uploads/{unique_name}"
    }


# POST /api/upload
# Accepts one or more files (field name "files") and returns { success, files: [...] }
@app.post("/api/upload")
async def api_upload(files: List[UploadFile] = File(...)):
    try:
        out = []
        for f in files:
            meta = _save_uploadfile(f)
            out.append(meta)
        return {"success": True, "files": out}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "error": str(e)})


# POST /api/chat (non-streaming fallback)
@app.post("/api/chat")
async def api_chat(request: Request):
    ct = request.headers.get("content-type", "")
    conversation_id = None

    try:
        if ct.startswith("multipart/form-data"):
            form = await request.form()
            file_obj = form.get("file")
            query = form.get("query") or form.get("message") or ""
            k = int(form.get("k") or 5)
            if not file_obj:
                return JSONResponse(status_code=400, content={"success": False, "error": "Missing 'file' in form."})
            if hasattr(file_obj, "filename"):
                pdf_bytes = await file_obj.read()
                loop = asyncio.get_running_loop()
                result = await loop.run_in_executor(None, backend.process_pdf_query, pdf_bytes, query, k)
            else:
                return JSONResponse(status_code=400, content={"success": False, "error": "Invalid 'file' upload."})
        else:
            body = await request.json()
            conversation_id = body.get("conversationId") or str(uuid.uuid4())
            message = body.get("message") or body.get("query") or ""
            file_ids = body.get("fileIds") or []
            k = int(body.get("k") or 5)

            if file_ids:
                first_id = file_ids[0]
                upload_path = os.path.join(UPLOADS_DIR, first_id)
                if not os.path.isfile(upload_path):
                    return JSONResponse(status_code=400, content={"success": False, "error": f"File id not found: {first_id}"})
                with open(upload_path, "rb") as f:
                    pdf_bytes = f.read()
                loop = asyncio.get_running_loop()
                result = await loop.run_in_executor(None, backend.process_pdf_query, pdf_bytes, message, k)
            else:
                result = {
                    "answer": f"Echo: {message}",
                    "retrieved": [],
                    "images": {},
                    "error": None
                }

        if not isinstance(result, dict):
            return JSONResponse(status_code=500, content={"success": False, "error": "backend returned unexpected response type"})

        if result.get("error"):
            return JSONResponse(status_code=500, content={"success": False, "error": result.get("error")})

        assistant_text = result.get("answer") or ""
        message_obj = {
            "id": uuid.uuid4().hex,
            "role": "assistant",
            "text": assistant_text,
            "timestamp": int(__import__("time").time() * 1000)
        }
        response_payload = {
            "success": True,
            "conversationId": conversation_id or str(uuid.uuid4()),
            "message": message_obj,
            "metadata": {
                "retrieved": result.get("retrieved", [])
            },
            "images": result.get("images", {})  # optional mapping image_id -> base64
        }
        return response_payload

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        return JSONResponse(status_code=500, content={"success": False, "error": str(e), "trace": tb})


# POST /api/stream_chat
# Streams the assistant text in small chunks (text/plain streamed response).
# Accepts a JSON body: { conversationId, message, fileIds, k } OR multipart/form-data similarly to /api/chat.
@app.post("/api/stream_chat")
async def api_stream_chat(request: Request):
    ct = request.headers.get("content-type", "")
    conversation_id = None

    try:
        # determine pdf_bytes and message
        pdf_bytes = None
        message = ""
        k = 5

        if ct.startswith("multipart/form-data"):
            form = await request.form()
            file_obj = form.get("file")
            message = form.get("query") or form.get("message") or ""
            k = int(form.get("k") or 5)
            if file_obj and hasattr(file_obj, "filename"):
                pdf_bytes = await file_obj.read()
        else:
            body = await request.json()
            conversation_id = body.get("conversationId") or str(uuid.uuid4())
            message = body.get("message") or body.get("query") or ""
            file_ids = body.get("fileIds") or []
            k = int(body.get("k") or 5)
            if file_ids:
                first_id = file_ids[0]
                upload_path = os.path.join(UPLOADS_DIR, first_id)
                if not os.path.isfile(upload_path):
                    # Stream an error message then close
                    async def err_gen():
                        yield f"ERROR: file id not found: {first_id}"
                    return StreamingResponse(err_gen(), media_type="text/plain; charset=utf-8")
                with open(upload_path, "rb") as f:
                    pdf_bytes = f.read()

        # Run backend processing in executor (blocking heavy work)
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, backend.process_pdf_query, pdf_bytes, message, k)

        if not isinstance(result, dict) or result.get("error"):
            # yield error as single chunk
            err_text = result.get("error") if isinstance(result, dict) else "Backend error"
            async def err_gen():
                yield err_text
            return StreamingResponse(err_gen(), media_type="text/plain; charset=utf-8")

        assistant_text = result.get("answer") or ""

        # Async generator that yields chunks of text (simulate streaming / typing)
        async def event_stream():
            # optional: send a small initial delay so frontend shows "thinking" state
            await asyncio.sleep(0.05)

            # Choose chunk size and delay to give a smooth typing effect.
            # Adjust these numbers for speed vs smoothness.
            chunk_size = 20  # characters per chunk
            delay_between_chunks = 0.03  # seconds

            # If assistant_text is empty, send an empty final chunk
            if not assistant_text:
                yield ""
                return

            # yield in slices
            pos = 0
            length = len(assistant_text)
            while pos < length:
                end = min(pos + chunk_size, length)
                piece = assistant_text[pos:end]
                yield piece
                pos = end
                # tiny sleep so the client can render progressively
                await asyncio.sleep(delay_between_chunks)

            # final newline/marker (optional)
            return

        return StreamingResponse(event_stream(), media_type="text/plain; charset=utf-8")

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        async def errgen():
            yield f"ERROR: {str(e)}\n{tb}"
        return StreamingResponse(errgen(), media_type="text/plain; charset=utf-8")


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("main:app", host="127.0.0.1", port=port, reload=True)