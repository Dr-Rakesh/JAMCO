# backend.py
import io
import os
import base64
import traceback

from typing import Tuple, List, Dict, Any

import fitz  # PyMuPDF
from PIL import Image
import numpy as np
import torch
from transformers import CLIPProcessor, CLIPModel
from sklearn.metrics.pairwise import cosine_similarity

from langchain_core.documents import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

from openai import AzureOpenAI
from azure.identity import DefaultAzureCredential

# ----------------- Azure OpenAI setup (Azure AD token provider) -----------------
AZURE_OPENAI_ENDPOINT = os.getenv(
    "AZURE_OPENAI_ENDPOINT",
    "https://openai-aiattack-msa-001758-swedencentral-adi.openai.azure.com/",
)
DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5")
API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview")

credential = DefaultAzureCredential()


def _bearer_token_provider():
    scope = "https://cognitiveservices.azure.com/.default"
    token = credential.get_token(scope)
    return token.token


client = AzureOpenAI(
    api_version=API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    azure_ad_token_provider=_bearer_token_provider,
)

# ----------------- CLIP model (load once) -----------------
device = "cuda" if torch.cuda.is_available() else "cpu"
_clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(device)
_clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
_clip_model.eval()

# ----------------- Helpers: embeddings -----------------
def embed_text(text: str) -> np.ndarray:
    """Return normalized CLIP text embedding as 1D numpy array."""
    inputs = _clip_processor(text=[text], return_tensors="pt", padding=True, truncation=True, max_length=77)
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        feats = _clip_model.get_text_features(**inputs)
        feats = feats / feats.norm(dim=-1, keepdim=True)
    return feats.squeeze(0).cpu().numpy()


def embed_image(pil_image: Image.Image) -> np.ndarray:
    """Return normalized CLIP image embedding as 1D numpy array."""
    inputs = _clip_processor(images=pil_image, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        feats = _clip_model.get_image_features(**inputs)
        feats = feats / feats.norm(dim=-1, keepdim=True)
    return feats.squeeze(0).cpu().numpy()


# ----------------- PDF processing + retrieval -----------------
def _extract_and_embed(pdf_bytes: bytes) -> Tuple[List[Document], np.ndarray, Dict[str, str]]:
    """
    Extract text chunks and images, compute CLIP embeddings.
    Returns:
      - list of Document objects (each with metadata type text or image)
      - embeddings matrix (n x d) as numpy ndarray
      - image_data_store: image_id -> base64 PNG
    """
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    all_docs: List[Document] = []
    all_embeddings: List[np.ndarray] = []
    image_data_store: Dict[str, str] = {}

    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)

    for page_num, page in enumerate(doc):
        # text
        text = page.get_text().strip()
        if text:
            temp_doc = Document(page_content=text, metadata={"page": page_num, "type": "text"})
            text_chunks = splitter.split_documents([temp_doc])
            for chunk in text_chunks:
                emb = embed_text(chunk.page_content)
                all_embeddings.append(emb)
                all_docs.append(chunk)

        # images
        for img_index, img in enumerate(page.get_images(full=True)):
            try:
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                pil_image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

                image_id = f"page_{page_num}_img_{img_index}"
                buffered = io.BytesIO()
                pil_image.save(buffered, format="PNG")
                img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
                image_data_store[image_id] = img_b64

                emb = embed_image(pil_image)
                all_embeddings.append(emb)

                image_doc = Document(
                    page_content=f"[Image: {image_id}]",
                    metadata={"page": page_num, "type": "image", "image_id": image_id},
                )
                all_docs.append(image_doc)
            except Exception:
                # don't fail the whole extraction on one broken image
                continue

    doc.close()

    if len(all_embeddings) == 0:
        raise RuntimeError("No embeddings extracted from PDF (empty or unsupported PDF).")

    embeddings_matrix = np.vstack([np.asarray(e).reshape(1, -1) for e in all_embeddings])
    return all_docs, embeddings_matrix, image_data_store


def _build_message_content(query: str, retrieved_docs: List[Document], image_data_store: Dict[str, str]) -> str:
    parts = []
    parts.append("Question: " + query + "\n\nContext:\n")

    text_docs = [d for d in retrieved_docs if d.metadata.get("type") == "text"]
    image_docs = [d for d in retrieved_docs if d.metadata.get("type") == "image"]

    if text_docs:
        parts.append("Text excerpts:\n")
        for d in text_docs:
            page = d.metadata.get("page", "?")
            excerpt = d.page_content.strip()
            if len(excerpt) > 800:
                excerpt = excerpt[:800] + "..."
            parts.append(f"[Page {page}]: {excerpt}\n\n")

    if image_docs:
        parts.append("\nImages:\n")
        for d in image_docs:
            page = d.metadata.get("page", "?")
            img_id = d.metadata.get("image_id")
            if img_id and img_id in image_data_store:
                data_url = f"data:image/png;base64,{image_data_store[img_id]}"
                parts.append(f"![Image {img_id} (page {page})]({data_url})\n\n")
            else:
                parts.append(f"[Image {img_id} from page {page} not found]\n\n")

    parts.append("\nPlease answer the question based on the provided text and images. Be concise but thorough.")
    return "".join(parts)


def _retrieve_top_k(query: str, embeddings_matrix: np.ndarray, all_docs: List[Document], k: int = 5):
    q_emb = embed_text(query).reshape(1, -1)
    sims = cosine_similarity(q_emb, embeddings_matrix).squeeze(0)
    top_idxs = np.argsort(sims)[::-1][:k]
    results = [all_docs[i] for i in top_idxs]
    scores = sims[top_idxs]
    return results, top_idxs, scores


# ----------------- Public function to call from main server -----------------
def process_pdf_query(pdf_bytes: bytes, query: str, k: int = 5, max_tokens: int = 1024) -> Dict[str, Any]:
    """
    High-level function:
      - extract text & images from pdf_bytes
      - embed and retrieve top-k docs using CLIP
      - assemble a single chat message (text + inline images as data URLs)
      - call Azure OpenAI chat completion and return the assistant reply plus metadata
    Returns dict:
      {
        "answer": "<assistant text>",
        "retrieved": [ { "type": "text" | "image", "page": int, "preview": str, "image_id": str|None, "score": float }, ... ],
        "error": None or "<error message>"
      }
    """
    try:
        all_docs, embeddings_matrix, image_data_store = _extract_and_embed(pdf_bytes)
        retrieved_docs, idxs, scores = _retrieve_top_k(query, embeddings_matrix, all_docs, k=k)
        content = _build_message_content(query, retrieved_docs, image_data_store)

        messages = [
            {"role": "system", "content": "You are a helpful multimodal assistant. Use the provided text and images to answer the question."},
            {"role": "user", "content": content},
        ]

        # NOTE: some Azure deployments do not accept non-default temperature, so we omit temperature
        response = client.chat.completions.create(
            model=DEPLOYMENT_NAME,
            messages=messages,
            max_completion_tokens=max_tokens,
        )

        assistant_msg = ""
        try:
            assistant_msg = response.choices[0].message.content
        except Exception:
            assistant_msg = str(response)

        # Build retrieved metadata to return to caller (for debugging / UI)
        retrieved_meta = []
        for doc, idx, score in zip(retrieved_docs, idxs, scores):
            m = doc.metadata
            if m.get("type") == "text":
                preview = doc.page_content.strip()[:300].replace("\n", " ")
                retrieved_meta.append({"type": "text", "page": m.get("page"), "preview": preview, "image_id": None, "score": float(score)})
            else:
                retrieved_meta.append({"type": "image", "page": m.get("page"), "preview": None, "image_id": m.get("image_id"), "score": float(score)})

        return {"answer": assistant_msg, "retrieved": retrieved_meta, "error": None}

    except Exception as e:
        tb = traceback.format_exc()
        return {"answer": None, "retrieved": [], "error": f"{str(e)}\n{tb}"}