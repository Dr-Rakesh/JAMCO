import os
import json
import asyncio
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn
from excel import get_rag_instance

app = FastAPI(title="Tabular RAG API")

# Configuration
UPLOAD_FOLDER = 'static/uploads'
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
ALLOWED_EXTENSIONS = {'csv', 'xlsx', 'xls'}

# Ensure upload directory exists
Path(UPLOAD_FOLDER).mkdir(parents=True, exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Pydantic models for request/response
class ChatRequest(BaseModel):
    conversationId: Optional[str] = None
    message: str
    fileIds: List[str] = []

class UploadResponse(BaseModel):
    success: bool
    files: List[Dict[str, Any]] = []
    error: Optional[str] = None

def allowed_file(filename: str) -> bool:
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def generate_file_id(filename: str) -> str:
    """Generate unique file ID"""
    timestamp = datetime.now().isoformat()
    return hashlib.md5(f"{filename}_{timestamp}".encode()).hexdigest()[:12]

def secure_filename(filename: str) -> str:
    """Sanitize filename for safe storage"""
    # Remove any path components
    filename = os.path.basename(filename)
    # Replace spaces and special characters
    filename = "".join(c if c.isalnum() or c in ".-_" else "_" for c in filename)
    return filename

@app.get("/", response_class=HTMLResponse)
async def index():
    """Serve the main HTML page"""
    file_path = Path("static/index.html")
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="index.html not found")
    
    # Read file synchronously (simpler than async)
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    return HTMLResponse(content=content)

@app.post("/api/upload")
async def upload_files(files: List[UploadFile] = File(...)):
    """Handle file upload"""
    uploaded_files = []
    rag = get_rag_instance()
    
    for file in files:
        # Check file size
        contents = await file.read()
        if len(contents) > MAX_FILE_SIZE:
            continue
        
        if file.filename and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_id = generate_file_id(filename)
            
            # Save file
            file_path = os.path.join(UPLOAD_FOLDER, f"{file_id}_{filename}")
            
            # Write file synchronously
            with open(file_path, 'wb') as f:
                f.write(contents)
            
            # Load into RAG system
            if rag.load_file(file_path, file_id):
                uploaded_files.append({
                    'id': file_id,
                    'name': filename,
                    'url': f"/static/uploads/{file_id}_{filename}",
                    'size': len(contents)
                })
    
    return UploadResponse(
        success=len(uploaded_files) > 0,
        files=uploaded_files
    )

@app.post("/api/stream_chat")
async def stream_chat(request: ChatRequest):
    """Handle chat messages with streaming response"""
    
    async def generate():
        """Async generator for streaming response"""
        rag = get_rag_instance()
        
        # Process the query (run in thread pool to avoid blocking)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None, 
            rag.query_data_with_llm, 
            request.message, 
            request.fileIds
        )
        
        # Stream the answer text
        answer = result.get('answer', '')
        
        # Send text in chunks
        chunk_size = 50
        for i in range(0, len(answer), chunk_size):
            chunk = answer[i:i+chunk_size]
            yield json.dumps({'type': 'message', 'text': chunk}) + '\n'
            await asyncio.sleep(0.01)  # Small delay for smooth streaming
            
        # Send metadata (table and charts) at the end
        meta_data = {
            'table': result.get('table'),
            'charts': result.get('charts')
        }
        
        if meta_data['table'] or meta_data['charts']:
            yield json.dumps({'type': 'meta', 'data': meta_data}) + '\n'
    
    return StreamingResponse(
        generate(),
        media_type='application/x-ndjson',
        headers={
            'Cache-Control': 'no-cache',
            'X-Accel-Buffering': 'no'
        }
    )

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    }

@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    # Ensure directories exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    
    # Initialize RAG instance
    rag = get_rag_instance()
    print("✅ RAG system initialized")
    print(f"✅ Upload folder ready at: {UPLOAD_FOLDER}")
    print("📄 API documentation available at: http://localhost:5000/docs")

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handle general exceptions"""
    return JSONResponse(
        status_code=500,
        content={"error": str(exc), "type": type(exc).__name__}
    )

if __name__ == "__main__":
    # Run with uvicorn
    uvicorn.run(
        app,  # Use app directly instead of string import
        host="0.0.0.0",
        port=5000,
        reload=False,  # Set to False to avoid reload issues
        log_level="info"
    )