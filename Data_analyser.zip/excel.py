import os
import json
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional
import hashlib
from datetime import datetime
from openai import AzureOpenAI
from azure.identity import DefaultAzureCredential
import traceback
import logging
import re

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TabularRAG:
    def __init__(self, upload_dir: str = "static/uploads"):
        self.upload_dir = upload_dir
        self.dataframes = {}  # Store loaded dataframes by file_id
        
        # Azure OpenAI Configuration
        self.endpoint = "https://openai-aiattack-msa-001758-swedencentral-adi.openai.azure.com/"
        self.deployment = "gpt-5"
        self.api_version = "2024-12-01-preview"
        
        # Initialize Azure credentials
        try:
            self.credential = DefaultAzureCredential()
            self.client = AzureOpenAI(
                api_version=self.api_version,
                azure_endpoint=self.endpoint,
                azure_ad_token_provider=self._bearer_token_provider,
            )
        except Exception as e:
            logger.error(f"Error initializing Azure OpenAI: {e}")
            self.client = None
    
    def _bearer_token_provider(self):
        """Return an access token string for the required scope."""
        try:
            scope = "https://cognitiveservices.azure.com/.default"
            token = self.credential.get_token(scope)
            return token.token
        except Exception as e:
            logger.error(f"Error getting bearer token: {e}")
            return None
        
    def load_file(self, file_path: str, file_id: str) -> bool:
        """Load CSV or Excel file into memory"""
        try:
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path)
            elif file_path.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(file_path)
            else:
                return False
            
            self.dataframes[file_id] = df
            logger.info(f"Loaded file with {len(df)} rows and columns: {df.columns.tolist()}")
            return True
        except Exception as e:
            logger.error(f"Error loading file {file_path}: {e}")
            return False
    
    def _safe_convert_to_float(self, value) -> float:
        """Safely convert a value to float"""
        try:
            if pd.isna(value) or value is None:
                return 0.0
            if isinstance(value, str):
                # Remove common non-numeric characters
                cleaned = value.replace('$', '').replace(',', '').replace('%', '').strip()
                if cleaned == '' or cleaned.lower() in ['n/a', 'na', 'null', 'none', '-']:
                    return 0.0
                return float(cleaned)
            if isinstance(value, (int, float, np.integer, np.floating)):
                return float(value)
            return 0.0
        except (ValueError, TypeError, AttributeError):
            return 0.0
    
    def _detect_column_types(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """Dynamically detect and categorize column types"""
        column_types = {
            "numeric": [],
            "categorical": [],
            "datetime": [],
            "text": [],
            "identifier": [],
            "boolean": []
        }
        
        for col in df.columns:
            try:
                # Check for datetime
                if pd.api.types.is_datetime64_any_dtype(df[col]):
                    column_types["datetime"].append(col)
                # Try to convert to datetime if it looks like a date string
                elif df[col].dtype == 'object':
                    # Sample first non-null value
                    sample_values = df[col].dropna().head(5)
                    if not sample_values.empty:
                        sample = str(sample_values.iloc[0])
                        # Check if it looks like a date
                        if any(sep in sample for sep in ['-', '/', '.']) and len(sample) >= 8:
                            try:
                                pd.to_datetime(sample_values)
                                column_types["datetime"].append(col)
                                continue
                            except:
                                pass
                    
                    # Not a date, check other string types
                    unique_ratio = df[col].nunique() / len(df) if len(df) > 0 else 0
                    avg_length = df[col].astype(str).str.len().mean() if len(df) > 0 else 0
                    
                    if unique_ratio < 0.5 and avg_length < 50:
                        column_types["categorical"].append(col)
                    elif unique_ratio > 0.9:
                        column_types["identifier"].append(col)
                    else:
                        column_types["text"].append(col)
                
                # Check for numeric
                elif pd.api.types.is_numeric_dtype(df[col]):
                    column_types["numeric"].append(col)
                    # Check if it might be an ID (high cardinality integers)
                    if df[col].dtype in ['int64', 'int32']:
                        unique_ratio = df[col].nunique() / len(df) if len(df) > 0 else 0
                        # Also check if column name suggests it's an ID
                        id_keywords = ['id', 'number', 'code', 'key', 'room']
                        is_id_like = any(keyword in col.lower() for keyword in id_keywords)
                        if unique_ratio > 0.9 or is_id_like:
                            column_types["identifier"].append(col)
                
                # Check for boolean
                elif df[col].dtype == 'bool':
                    column_types["boolean"].append(col)
                elif df[col].nunique() == 2:
                    unique_vals = df[col].dropna().unique()
                    if len(unique_vals) == 2:
                        column_types["boolean"].append(col)
            
            except Exception as e:
                logger.warning(f"Error detecting type for column {col}: {e}")
                # Default to text if we can't determine type
                column_types["text"].append(col)
        
        return column_types
    
    def _find_relevant_columns(self, query: str, df: pd.DataFrame) -> List[str]:
        """Find columns mentioned in the query"""
        try:
            query_lower = query.lower()
            relevant_cols = []
            
            for col in df.columns:
                col_lower = col.lower()
                # Check if column name or parts of it appear in query
                if col_lower in query_lower:
                    relevant_cols.append(col)
                else:
                    # Check for partial matches (words in column name)
                    col_words = col_lower.replace('_', ' ').replace('-', ' ').split()
                    for word in col_words:
                        if len(word) > 2 and word in query_lower:
                            relevant_cols.append(col)
                            break
            
            return list(set(relevant_cols))
        except Exception as e:
            logger.error(f"Error finding relevant columns: {e}")
            return []
    
    def _preprocess_query(self, query: str, df: pd.DataFrame) -> str:
        """Preprocess query to handle common issues"""
        try:
            # Normalize the query
            query = query.strip()
            
            # Map common terms to actual column names
            column_mapping = {}
            for col in df.columns:
                col_lower = col.lower()
                # Add variations
                if 'bill' in col_lower and 'amount' in col_lower:
                    column_mapping['billing'] = col
                    column_mapping['revenue'] = col
                    column_mapping['payment'] = col
                elif 'hospital' in col_lower:
                    column_mapping['facility'] = col
                    column_mapping['center'] = col
            
            # Replace terms in query
            for term, actual_col in column_mapping.items():
                if term in query.lower() and actual_col.lower() not in query.lower():
                    query = query.replace(term, actual_col)
                    
            return query
        except:
            return query
    
    def _analyze_query_intent(self, query: str) -> Dict[str, Any]:
        """Analyze query intent without domain-specific assumptions"""
        try:
            query_lower = query.lower()
            
            intent = {
                "operation": None,
                "aggregation": None,
                "sorting": None,
                "limit": None,
                "comparison": None,
                "grouping": False,
                "filtering": False
            }
            
            # Detect operations
            if any(word in query_lower for word in ["highest", "maximum", "top", "most", "largest", "biggest", "greatest"]):
                intent["operation"] = "max"
                intent["sorting"] = "desc"
            elif any(word in query_lower for word in ["lowest", "minimum", "bottom", "least", "smallest", "fewest"]):
                intent["operation"] = "min"
                intent["sorting"] = "asc"
            elif any(word in query_lower for word in ["average", "mean", "avg"]):
                intent["operation"] = "mean"
                intent["aggregation"] = "mean"
            elif any(word in query_lower for word in ["sum", "total", "combined", "aggregate"]):
                intent["operation"] = "sum"
                intent["aggregation"] = "sum"
            elif any(word in query_lower for word in ["count", "how many", "number of", "frequency"]):
                intent["operation"] = "count"
                intent["aggregation"] = "count"
            elif any(word in query_lower for word in ["unique", "distinct", "different"]):
                intent["operation"] = "unique"
            elif any(word in query_lower for word in ["duplicate", "repeated", "multiple", "more than once"]):
                intent["operation"] = "duplicate"
            elif any(word in query_lower for word in ["group", "grouped", "by each", "per", "breakdown"]):
                intent["grouping"] = True
            elif any(word in query_lower for word in ["correlation", "relationship", "associated"]):
                intent["operation"] = "correlation"
            elif any(word in query_lower for word in ["trend", "over time", "timeline", "progression"]):
                intent["operation"] = "trend"
            elif any(word in query_lower for word in ["distribution", "spread", "range"]):
                intent["operation"] = "distribution"
            
            # Detect filtering
            if any(word in query_lower for word in ["where", "filter", "only", "with", "having"]):
                intent["filtering"] = True
            
            # Detect limit
            numbers = re.findall(r'\b(\d+)\b', query_lower)
            if numbers and any(word in query_lower for word in ["top", "first", "last", "bottom"]):
                intent["limit"] = int(numbers[0])
            
            return intent
        except Exception as e:
            logger.error(f"Error analyzing query intent: {e}")
            return {"operation": None, "aggregation": None, "sorting": None, "limit": None, "grouping": False, "filtering": False}
    
    def _execute_dynamic_analysis(self, df: pd.DataFrame, query: str) -> Optional[str]:
        """Execute analysis dynamically based on data and query"""
        try:
            query = self._preprocess_query(query, df)
            intent = self._analyze_query_intent(query)
            relevant_cols = self._find_relevant_columns(query, df)
            column_types = self._detect_column_types(df)
            
            result = None
            
            # Filter out identifier columns from numeric columns
            valid_numeric = [col for col in column_types["numeric"] if col not in column_types.get("identifier", [])]
            
            # If specific columns are mentioned, focus on them
            if relevant_cols:
                # Handle different operations based on column types
                if intent["operation"] in ["max", "min"]:
                    for col in relevant_cols:
                        if col in valid_numeric:
                            if intent["grouping"]:
                                # Find a categorical column for grouping
                                group_cols = [c for c in relevant_cols if c in column_types["categorical"]]
                                if not group_cols and column_types["categorical"]:
                                    group_cols = [column_types["categorical"][0]]
                                
                                if group_cols:
                                    grouped = df.groupby(group_cols[0])[col].agg(['sum', 'mean', 'count']).reset_index()
                                    if intent["operation"] == "max":
                                        sorted_df = grouped.nlargest(5, 'sum')
                                    else:
                                        sorted_df = grouped.nsmallest(5, 'sum')
                                    
                                    result = f"Analysis of {col} by {group_cols[0]}:\n\n"
                                    for _, row in sorted_df.iterrows():
                                        result += f"{row[group_cols[0]]}: Sum={row['sum']:.2f}, Mean={row['mean']:.2f}, Count={row['count']}\n"
                            else:
                                # Simple max/min
                                limit = min(intent.get("limit", 5), len(df))
                                if intent["operation"] == "max":
                                    sorted_df = df.nlargest(limit, col)
                                    result = f"Top {limit} by {col}:\n\n"
                                else:
                                    sorted_df = df.nsmallest(limit, col)
                                    result = f"Bottom {limit} by {col}:\n\n"
                                
                                # Find a good identifier column
                                id_cols = column_types.get("identifier", []) + column_types.get("categorical", []) + column_types.get("text", [])
                                if id_cols:
                                    id_col = id_cols[0]
                                    for _, row in sorted_df.iterrows():
                                        try:
                                            result += f"- {row[id_col]}: {row[col]:.2f}\n"
                                        except:
                                            result += f"- {row[id_col]}: {row[col]}\n"
                                else:
                                    for idx, row in sorted_df.iterrows():
                                        try:
                                            result += f"- Row {idx}: {row[col]:.2f}\n"
                                        except:
                                            result += f"- Row {idx}: {row[col]}\n"
                            break
                
                elif intent["aggregation"]:
                    numeric_cols = [col for col in relevant_cols if col in valid_numeric]
                    if numeric_cols:
                        result = f"Statistical Analysis:\n\n"
                        for col in numeric_cols:
                            try:
                                if intent["aggregation"] == "mean":
                                    value = df[col].mean()
                                    result += f"{col} Average: {value:.2f}\n"
                                elif intent["aggregation"] == "sum":
                                    value = df[col].sum()
                                    result += f"{col} Total: {value:.2f}\n"
                                elif intent["aggregation"] == "count":
                                    value = df[col].count()
                                    result += f"{col} Count: {value}\n"
                                
                                # Add additional statistics
                                result += f"  Min: {df[col].min():.2f}\n"
                                result += f"  Max: {df[col].max():.2f}\n"
                                result += f"  Median: {df[col].median():.2f}\n"
                            except:
                                continue
                
                elif intent["operation"] == "unique":
                    for col in relevant_cols:
                        unique_values = df[col].unique()
                        result = f"Unique values in {col} ({len(unique_values)} total):\n\n"
                        for val in unique_values[:20]:  # Limit to 20
                            result += f"- {val}\n"
                        if len(unique_values) > 20:
                            result += f"... and {len(unique_values) - 20} more"
                        break
                
                elif intent["operation"] == "duplicate":
                    for col in relevant_cols:
                        value_counts = df[col].value_counts()
                        duplicates = value_counts[value_counts > 1]
                        if len(duplicates) > 0:
                            result = f"Values appearing multiple times in {col}:\n\n"
                            for val, count in duplicates.head(10).items():
                                result += f"- {val}: appears {count} times\n"
                        else:
                            result = f"No duplicate values found in {col}"
                        break
            
            # If no specific columns mentioned, analyze based on intent
            elif intent["operation"] or intent["aggregation"]:
                if intent["operation"] in ["max", "min"] and valid_numeric:
                    col = valid_numeric[0]
                    limit = min(intent.get("limit", 5), len(df))
                    if intent["operation"] == "max":
                        sorted_df = df.nlargest(limit, col)
                        result = f"Top {limit} by {col}:\n\n"
                    else:
                        sorted_df = df.nsmallest(limit, col)
                        result = f"Bottom {limit} by {col}:\n\n"
                    
                    # Show results
                    for idx, row in sorted_df.iterrows():
                        row_desc = f"Row {idx}"
                        if column_types.get("identifier"):
                            row_desc = str(row[column_types["identifier"][0]])
                        elif column_types.get("categorical"):
                            row_desc = str(row[column_types["categorical"][0]])
                        try:
                            result += f"- {row_desc}: {row[col]:.2f}\n"
                        except:
                            result += f"- {row_desc}: {row[col]}\n"
                
                elif intent["aggregation"] and valid_numeric:
                    result = "Statistical Summary:\n\n"
                    for col in valid_numeric[:5]:  # Limit to 5 columns
                        try:
                            result += f"{col}:\n"
                            result += f"  Mean: {df[col].mean():.2f}\n"
                            result += f"  Sum: {df[col].sum():.2f}\n"
                            result += f"  Min: {df[col].min():.2f}\n"
                            result += f"  Max: {df[col].max():.2f}\n\n"
                        except:
                            continue
            
            return result
        except Exception as e:
            logger.error(f"Error in dynamic analysis: {e}")
            return None
    
    def _create_dynamic_context(self, df: pd.DataFrame, query: str) -> str:
        """Create context dynamically based on the data"""
        try:
            column_types = self._detect_column_types(df)
            relevant_cols = self._find_relevant_columns(query, df)
            
            context = f"Dataset Information:\n"
            context += f"- Rows: {len(df)}\n"
            context += f"- Columns: {len(df.columns)}\n\n"
            
            context += "Column Details:\n"
            
            # Prioritize relevant columns
            cols_to_describe = relevant_cols + [col for col in df.columns if col not in relevant_cols]
            cols_to_describe = cols_to_describe[:15]  # Limit to 15 columns
            
            for col in cols_to_describe:
                try:
                    context += f"\n{col}:\n"
                    context += f"  Type: {df[col].dtype}\n"
                    
                    valid_numeric = [c for c in column_types.get("numeric", []) if c not in column_types.get("identifier", [])]
                    
                    if col in valid_numeric:
                        context += f"  Range: {df[col].min():.2f} to {df[col].max():.2f}\n"
                        context += f"  Mean: {df[col].mean():.2f}\n"
                        context += f"  Median: {df[col].median():.2f}\n"
                    elif col in column_types.get("categorical", []) or (df[col].nunique() <= 20):
                        value_counts = df[col].value_counts().head(5)
                        context += f"  Unique values: {df[col].nunique()}\n"
                        context += f"  Top values:\n"
                        for val, count in value_counts.items():
                            context += f"    - {val}: {count} ({count/len(df)*100:.1f}%)\n"
                    else:
                        context += f"  Unique values: {df[col].nunique()}\n"
                        sample_values = df[col].dropna().head(3).tolist()
                        if sample_values:
                            context += f"  Sample values: {', '.join(map(str, sample_values))}\n"
                except Exception as e:
                    logger.warning(f"Error describing column {col}: {e}")
                    continue
            
            # Add sample rows
            context += "\n\nSample Data:\n"
            try:
                sample_df = df.head(5)
                context += sample_df.to_string()
            except:
                context += "Error displaying sample data"
            
            # Keep context manageable
            if len(context) > 10000:
                context = context[:10000] + "\n...(truncated)"
            
            return context
        except Exception as e:
            logger.error(f"Error creating context: {e}")
            return f"Dataset with {len(df)} rows and {len(df.columns)} columns"
    
    def _call_llm_with_retry(self, messages: List[Dict], df: pd.DataFrame, max_retries: int = 3) -> str:
        """Call LLM with retry logic"""
        for attempt in range(max_retries):
            try:
                if not self.client:
                    return self._basic_data_summary(df)
                    
                completion = self.client.chat.completions.create(
                    model=self.deployment,
                    messages=messages,
                    max_completion_tokens=1000,
                    temperature=1,
                    timeout=30  # Add timeout
                )
                return completion.choices[0].message.content
                
            except Exception as e:
                logger.warning(f"LLM call attempt {attempt + 1} failed: {e}")
                if attempt == max_retries - 1:
                    return self._basic_data_summary(df)
        
        return self._basic_data_summary(df)
    
    def query_data_with_llm(self, query: str, file_ids: List[str]) -> Dict[str, Any]:
        """Process natural language query using Azure OpenAI"""
        response = {
            "answer": "",
            "table": None,
            "charts": None
        }
        
        try:
            # Get relevant dataframes
            relevant_dfs = []
            for fid in file_ids:
                if fid in self.dataframes:
                    relevant_dfs.append(self.dataframes[fid])
            
            if not relevant_dfs:
                response["answer"] = "No data files found. Please upload CSV or Excel files first."
                return response
            
            # Use the first dataframe
            df = relevant_dfs[0]
            
            # Preprocess query
            query = self._preprocess_query(query, df)
            
            # Try dynamic analysis first
            dynamic_result = self._execute_dynamic_analysis(df, query)
            
            if dynamic_result:
                response["answer"] = dynamic_result
            else:
                # Use LLM for complex queries
                if self.client:
                    try:
                        context = self._create_dynamic_context(df, query)
                        
                        system_prompt = """You are a data analyst. Analyze the data and answer questions precisely.
                        
Instructions:
- Answer the specific question asked
- Use actual values from the data
- Be concise but complete
- Include relevant statistics when appropriate
- If the question cannot be answered from the data, explain why"""
                        
                        user_prompt = f"""Data Context:
{context}

Question: {query}

Provide a data-driven answer based on the information available."""

                        messages = [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_prompt}
                        ]
                        
                        response["answer"] = self._call_llm_with_retry(messages, df)
                        
                    except Exception as e:
                        logger.error(f"Error calling Azure OpenAI: {e}")
                        response["answer"] = self._basic_data_summary(df)
                else:
                    # No LLM available, use basic analysis
                    response["answer"] = self._basic_data_summary(df)
            
            # Get column types for chart validation
            column_types = self._detect_column_types(df)
            
            # Generate table with error handling
            try:
                response["table"] = self._generate_dynamic_table(df, query)
            except Exception as e:
                logger.error(f"Table generation failed: {e}")
                response["table"] = {"columns": df.columns.tolist()[:5], "preview_rows": []}
            
            # Generate charts with validation
            try:
                if self._validate_chart_data(df, column_types):
                    response["charts"] = self._generate_dynamic_charts(df, query)
                else:
                    response["charts"] = {}
            except Exception as e:
                logger.error(f"Chart generation failed: {e}")
                response["charts"] = {}
            
        except Exception as e:
            logger.error(f"Error in query_data_with_llm: {e}")
            response["answer"] = f"An error occurred while processing your query. Please try rephrasing or check your data."
        
        return response
    
    def _validate_chart_data(self, df: pd.DataFrame, column_types: Dict) -> bool:
        """Validate if data is suitable for chart generation"""
        try:
            numeric_cols = [col for col in column_types.get("numeric", []) 
                           if col not in column_types.get("identifier", [])]
            
            if not numeric_cols:
                return False
                
            # Check if we have valid numeric data
            for col in numeric_cols[:1]:  # Check at least one column
                if col not in df.columns:
                    continue
                if df[col].dtype in ['object', 'string']:
                    return False
                if df[col].isna().all():
                    return False
                    
            return True
        except:
            return False
    
    def _basic_data_summary(self, df: pd.DataFrame) -> str:
        """Provide basic data summary as fallback"""
        try:
            column_types = self._detect_column_types(df)
            
            summary = f"Dataset Summary:\n"
            summary += f"- Total records: {len(df)}\n"
            summary += f"- Total columns: {len(df.columns)}\n"
            
            valid_numeric = [c for c in column_types.get("numeric", []) if c not in column_types.get("identifier", [])]
            
            summary += f"- Numeric columns: {len(valid_numeric)}\n"
            summary += f"- Categorical columns: {len(column_types.get('categorical', []))}\n"
            summary += f"- Text columns: {len(column_types.get('text', []))}\n"
            
            if valid_numeric:
                summary += f"\nNumeric columns: {', '.join(valid_numeric[:5])}\n"
            if column_types.get('categorical'):
                summary += f"Categorical columns: {', '.join(column_types['categorical'][:5])}\n"
            
            return summary
        except Exception as e:
            logger.error(f"Error creating basic summary: {e}")
            return f"Dataset with {len(df)} rows and {len(df.columns)} columns"
    
    def _get_default_table(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Get a default table view when normal generation fails"""
        try:
            preview_df = df.head(10)
            columns = preview_df.columns.tolist()[:10]
            
            preview_rows = []
            for idx, row in preview_df.iterrows():
                row_dict = {}
                for col in columns:
                    try:
                        value = row[col]
                        if pd.isna(value):
                            row_dict[col] = None
                        else:
                            row_dict[col] = str(value)
                    except:
                        row_dict[col] = ""
                preview_rows.append({"row": row_dict})
            
            return {
                "columns": columns,
                "preview_rows": preview_rows
            }
        except Exception as e:
            logger.error(f"Error generating default table: {e}")
            return {"columns": [], "preview_rows": []}
    
    def _generate_dynamic_table(self, df: pd.DataFrame, query: str) -> Dict[str, Any]:
        """Generate table dynamically based on query"""
        try:
            intent = self._analyze_query_intent(query)
            relevant_cols = self._find_relevant_columns(query, df)
            column_types = self._detect_column_types(df)
            
            # Determine rows to show
            preview_df = df.head(10)
            
            # Filter out identifier columns from numeric columns
            valid_numeric = [col for col in column_types.get("numeric", []) if col not in column_types.get("identifier", [])]
            
            if intent.get("sorting") and valid_numeric:
                sort_col = None
                # Try to use relevant numeric column
                for col in relevant_cols:
                    if col in valid_numeric:
                        sort_col = col
                        break
                
                if not sort_col and valid_numeric:
                    sort_col = valid_numeric[0]
                
                if sort_col:
                    try:
                        if intent["sorting"] == "desc":
                            preview_df = df.nlargest(min(10, len(df)), sort_col)
                        else:
                            preview_df = df.nsmallest(min(10, len(df)), sort_col)
                    except:
                        preview_df = df.head(10)
            
            # Select columns to show
            columns = []
            if relevant_cols:
                columns.extend(relevant_cols)
            
            # Add other important columns
            for col_type in ["categorical", "numeric"]:
                if col_type in column_types:
                    for col in column_types[col_type]:
                        if col not in columns and col not in column_types.get("identifier", []):
                            columns.append(col)
                        if len(columns) >= 10:
                            break
                if len(columns) >= 10:
                    break
            
            if not columns:
                columns = df.columns.tolist()[:10]
            
            # Create preview rows
            preview_rows = []
            for idx, row in preview_df.iterrows():
                row_dict = {}
                for col in columns[:10]:  # Limit to 10 columns
                    if col in df.columns:
                        try:
                            value = row[col]
                            if pd.isna(value):
                                row_dict[col] = None
                            elif isinstance(value, (np.integer, np.floating)):
                                row_dict[col] = float(value)
                            else:
                                row_dict[col] = str(value)
                        except:
                            row_dict[col] = ""
                preview_rows.append({"row": row_dict})
            
            return {
                "columns": columns[:10],
                "preview_rows": preview_rows
            }
        except Exception as e:
            logger.error(f"Error generating dynamic table: {e}")
            return self._get_default_table(df)
    
    def _generate_dynamic_charts(self, df: pd.DataFrame, query: str) -> Dict[str, Any]:
        """Generate charts dynamically based on data"""
        charts = {}
        
        try:
            column_types = self._detect_column_types(df)
            intent = self._analyze_query_intent(query)
            relevant_cols = self._find_relevant_columns(query, df)
            
            # Filter out identifier columns from numeric columns
            valid_numeric = [col for col in column_types.get("numeric", []) if col not in column_types.get("identifier", [])]
            
            if not valid_numeric:
                return charts
            
            # Determine data for visualization
            chart_df = df.head(20)
            
            if intent.get("sorting") and valid_numeric:
                sort_col = relevant_cols[0] if relevant_cols and relevant_cols[0] in valid_numeric else valid_numeric[0]
                try:
                    if intent["sorting"] == "desc":
                        chart_df = df.nlargest(min(20, len(df)), sort_col)
                    else:
                        chart_df = df.nsmallest(min(20, len(df)), sort_col)
                except:
                    chart_df = df.head(20)
            
            # Radar chart
            try:
                radar_data = self._create_radar_data(chart_df, column_types, relevant_cols)
                if radar_data:
                    charts["radar"] = radar_data
            except Exception as e:
                logger.warning(f"Error creating radar chart: {e}")
            
            # Area chart
            try:
                area_data = self._create_area_data(chart_df, column_types, relevant_cols)
                if area_data:
                    charts["area"] = area_data
            except Exception as e:
                logger.warning(f"Error creating area chart: {e}")
            
        except Exception as e:
            logger.error(f"Error generating charts: {e}")
        
        return charts
    
    def _create_radar_data(self, df: pd.DataFrame, column_types: Dict, relevant_cols: List[str]) -> Optional[Dict]:
        """Create radar chart data dynamically"""
        try:
            # Filter out identifier columns
            numeric_cols = [col for col in column_types.get("numeric", []) if col not in column_types.get("identifier", [])][:8]
            
            if len(numeric_cols) >= 3:
                labels = numeric_cols
                values = []
                
                for col in labels:
                    try:
                        # Normalize by max value
                        col_mean = df[col].mean()
                        col_max = df[col].max()
                        if col_max > 0:
                            normalized = col_mean / col_max
                        else:
                            normalized = 0
                        values.append(round(normalized, 3))
                    except:
                        values.append(0)
                
                if values and any(v > 0 for v in values):
                    return {"labels": labels, "values": values}
            
            # Option 2: Use categories as labels with numeric value
            if column_types.get("categorical") and numeric_cols:
                cat_col = column_types["categorical"][0]
                num_col = numeric_cols[0]
                
                try:
                    grouped = df.groupby(cat_col)[num_col].mean().head(8)
                    
                    if len(grouped) >= 3:
                        labels = [str(label) for label in grouped.index.tolist()]
                        values = grouped.values.tolist()
                        max_val = max(values) if values else 1
                        values = [round(v/max_val, 3) if max_val > 0 else 0 for v in values]
                        
                        if any(v > 0 for v in values):
                            return {"labels": labels, "values": values}
                except:
                    pass
        except Exception as e:
            logger.warning(f"Error in _create_radar_data: {e}")
        
        return None
    
    def _create_area_data(self, df: pd.DataFrame, column_types: Dict, relevant_cols: List[str]) -> Optional[Dict]:
        """Create area chart data dynamically"""
        try:
            # Determine x-axis labels
            labels = []
            
            if column_types.get("datetime"):
                # Use datetime for x-axis
                date_col = column_types["datetime"][0]
                try:
                    df_sorted = df.sort_values(date_col).head(20)
                    labels = df_sorted[date_col].astype(str).tolist()
                except:
                    labels = []
            
            if not labels and column_types.get("categorical"):
                # Use categorical
                cat_col = column_types["categorical"][0]
                try:
                    labels = df[cat_col].head(20).astype(str).tolist()
                except:
                    labels = []
            
            if not labels:
                # Use row numbers
                labels = [f"Point {i+1}" for i in range(min(20, len(df)))]
            
            # Select only valid numeric columns for datasets
            valid_numeric_cols = [
                col for col in column_types.get("numeric", []) 
                if col not in column_types.get("identifier", [])
            ]
            
            # Prioritize relevant columns if they're numeric
            if relevant_cols:
                dataset_cols = [col for col in relevant_cols if col in valid_numeric_cols]
                if not dataset_cols:
                    dataset_cols = valid_numeric_cols[:3]
            else:
                dataset_cols = valid_numeric_cols[:3]
            
            datasets = []
            for col in dataset_cols:
                if col in df.columns:
                    try:
                        # Get the data and ensure it's numeric
                        col_data = df[col].head(20)
                        
                        # Convert to numeric, handling any non-numeric values
                        numeric_data = []
                        for value in col_data:
                            numeric_data.append(self._safe_convert_to_float(value))
                        
                        if any(v != 0 for v in numeric_data):  # Only add if there's actual data
                            datasets.append({
                                "label": col,
                                "data": numeric_data
                            })
                    except Exception as e:
                        logger.warning(f"Error processing column {col} for area chart: {e}")
                        continue
            
            if datasets and labels:
                # Ensure labels and data have same length
                min_length = min(len(labels), 20)
                labels = labels[:min_length]
                for dataset in datasets:
                    dataset["data"] = dataset["data"][:min_length]
                
                return {"labels": labels, "datasets": datasets}
        
        except Exception as e:
            logger.warning(f"Error in _create_area_data: {e}")
        
        return None

# Global instance
rag_instance = None

def get_rag_instance():
    global rag_instance
    if rag_instance is None:
        rag_instance = TabularRAG()
    return rag_instance