# backend.py
import io
import json
import traceback
from typing import Dict, Any, List, Optional

import numpy as np
import pandas as pd
from datetime import datetime, date
from decimal import Decimal

from azure.identity import DefaultAzureCredential
from openai import AzureOpenAI
from azure.core.exceptions import ClientAuthenticationError, HttpResponseError

# Configuration - change these values as needed
AZURE_OPENAI_ENDPOINT = "https://openai-aiattack-msa-001758-swedencentral-adi.openai.azure.com"
DEPLOYMENT = "gpt-5"
API_VERSION = "2024-12-01-preview"

# Use DefaultAzureCredential (it will try multiple auth methods)
credential = DefaultAzureCredential()


def bearer_token_provider() -> str:
    scope = "https://cognitiveservices.azure.com/.default"
    token = credential.get_token(scope)
    return token.token


# Initialize Azure OpenAI client with the custom token provider
client = AzureOpenAI(
    api_version=API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    azure_ad_token_provider=bearer_token_provider,
)


# -----------------------
# Utility: JSON serializer
# -----------------------
def make_serializable(obj):
    if obj is None:
        return None
    if isinstance(obj, (str, bool, type(None))):
        return obj
    if isinstance(obj, (int, float)):
        if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
            return None
        return obj
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        v = float(obj)
        if np.isnan(v) or np.isinf(v):
            return None
        return v
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (np.ndarray,)):
        return [make_serializable(v) for v in obj.tolist()]
    if isinstance(obj, pd.Timestamp):
        try:
            return obj.isoformat()
        except Exception:
            return str(obj)
    if isinstance(obj, (pd.Timedelta,)):
        return str(obj)
    if obj is pd.NaT:
        return None
    if isinstance(obj, (pd.Series,)):
        return [make_serializable(v) for v in obj.tolist()]
    if isinstance(obj, pd.DataFrame):
        return [make_serializable(row) for row in obj.to_dict(orient="records")]
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return float(obj)
    if isinstance(obj, dict):
        return {str(k): make_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [make_serializable(v) for v in obj]
    try:
        if hasattr(obj, "item"):
            return make_serializable(obj.item())
    except Exception:
        pass
    return str(obj)


# -----------------------
# Datetime detection (strict inference per PDEP-4)
# -----------------------
def _guess_format_from_first_value(series: pd.Series) -> Optional[str]:
    """
    Try to guess a datetime format string from the first non-empty, non-NaN value.
    Uses pandas internal guess_datetime_format if available, otherwise returns None.
    """
    first_val = None
    for v in series.dropna().astype(str).values:
        if str(v).strip() != "":
            first_val = v
            break
    if first_val is None:
        return None

    try:
        # pandas internal helper; may not be present on all builds
        from pandas._libs.tslibs.parsing import guess_datetime_format

        fmt = guess_datetime_format(first_val)
        return fmt
    except Exception:
        return None


def detect_datetime_cols_strict(df: pd.DataFrame, min_non_null_ratio: float = 0.05) -> List[str]:
    """
    Strict datetime detection inspired by PDEP-4:
    - Try to guess format from the first non-null element and parse whole column with that format.
    - If that fails, try a small list of common formats.
    - Only coerce the column into datetime if enough values parse successfully (min_non_null_ratio).
    Returns list of detected datetime columns and coerces them in-place.
    """
    dt_cols = df.select_dtypes(include=["datetime", "datetimetz"]).columns.tolist()
    object_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    nrows = len(df)
    min_non_null = max(1, int(nrows * min_non_null_ratio))

    common_formats = [
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%m-%d-%Y",
        "%Y/%m/%d",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%Y-%m-%d %H:%M:%S",
        "%d-%m-%Y %H:%M:%S",
        "%m-%d-%Y %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
    ]

    for c in object_cols:
        series = df[c]
        # 1) try strict guess from first non-null
        fmt = _guess_format_from_first_value(series)
        if fmt:
            coerced = pd.to_datetime(series, format=fmt, errors="coerce")
            non_null = int(coerced.notna().sum())
            if non_null >= min_non_null:
                df[c] = coerced
                dt_cols.append(c)
                continue

        # 2) try a few common explicit formats
        matched = False
        for fmt_try in common_formats:
            coerced = pd.to_datetime(series, format=fmt_try, errors="coerce")
            non_null = int(coerced.notna().sum())
            if non_null >= min_non_null:
                df[c] = coerced
                dt_cols.append(c)
                matched = True
                break
        if matched:
            continue

        # 3) final fallback: flexible parsing (dateutil)
        # We only accept this if a sufficient fraction parses, and we record that it was flexible.
        coerced_flex = pd.to_datetime(series, errors="coerce")
        non_null_flex = int(coerced_flex.notna().sum())
        if non_null_flex >= min_non_null:
            df[c] = coerced_flex
            dt_cols.append(c)
            # Note: caller may wish to know this was a flexible fallback (not strictly inferred)
    return dt_cols


# -----------------------
# Data analysis helpers
# -----------------------
def dataframe_summary(df: pd.DataFrame) -> Dict[str, Any]:
    summary = {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "head": df.head(5).to_dict(orient="records"),
        "describe": df.describe(include="all").fillna("").to_dict(),
        "missing_values": df.isna().sum().to_dict(),
    }
    try:
        corr = df.select_dtypes(include=["number"]).corr()
        summary["correlation"] = corr.fillna(0).to_dict()
    except Exception:
        summary["correlation"] = {}
    return make_serializable(summary)


def detect_more_numeric_cols(df: pd.DataFrame, min_non_null_ratio: float = 0.05) -> List[str]:
    """
    Inspect object columns and try to coerce to numeric. If coercion yields enough non-null numeric values,
    treat the column as numeric for plotting/selection.
    Returns list of column names (including existing numeric columns).
    """
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    object_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    for c in object_cols:
        coerced = pd.to_numeric(df[c], errors="coerce")
        non_null = int(coerced.notna().sum())
        if non_null >= max(1, int(len(df) * min_non_null_ratio)):
            numeric_cols.append(c)
            # replace column in df with coerced numeric for plotting convenience
            df[c] = coerced
    return numeric_cols


def choose_columns_for_charts(df: pd.DataFrame) -> Dict[str, Any]:
    numeric_cols = detect_more_numeric_cols(df)
    datetime_cols = detect_datetime_cols_strict(df)
    object_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    chosen = {"scatter": None, "bar": None, "histogram": None, "area": None}

    # Scatter: two numeric columns with enough non-null values
    def good_numeric(col):
        return col in numeric_cols and int(df[col].dropna().shape[0]) >= max(2, int(len(df) * 0.01))

    numerics_ok = [c for c in numeric_cols if good_numeric(c)]
    if len(numerics_ok) >= 2:
        chosen["scatter"] = {"x": numerics_ok[0], "y": numerics_ok[1]}
    elif len(numerics_ok) == 1:
        chosen["scatter"] = {"x": numerics_ok[0], "y": numerics_ok[0]}

    # Bar: prefer categorical with manageable cardinality; fall back to numeric distribution
    cat_choice = None
    for c in object_cols:
        n_unique = int(df[c].nunique(dropna=True))
        if 1 < n_unique <= 50 and int(df[c].notna().sum()) >= max(1, int(len(df) * 0.01)):
            cat_choice = c
            break
    if cat_choice:
        agg_numeric = numerics_ok[0] if numerics_ok else None
        chosen["bar"] = {"cat": cat_choice, "agg": agg_numeric}
    else:
        if numerics_ok:
            chosen["bar"] = {"cat": None, "agg": numerics_ok[0]}

    # Histogram: choose numeric column with most non-null values
    if numerics_ok:
        counts = {c: int(df[c].count()) for c in numerics_ok}
        hist_col = max(counts, key=counts.get)
        chosen["histogram"] = {"col": hist_col}

    # Area: prefer time series if there's a datetime and a numeric; else try numeric cumulative
    if datetime_cols and numerics_ok:
        chosen["area"] = {"time": datetime_cols[0], "value": numerics_ok[0]}
    elif numerics_ok:
        chosen["area"] = {"value": numerics_ok[0]}
    else:
        chosen["area"] = None

    return chosen


def _sample_for_scatter(x_vals, y_vals, max_points=3000):
    """
    Sample up to max_points indices while keeping distribution (random sample).
    """
    n = len(x_vals)
    if n <= max_points:
        return list(zip(x_vals, y_vals))
    idx = np.random.choice(n, size=max_points, replace=False)
    return [(x_vals[i], y_vals[i]) for i in idx]


def build_chart_data(df: pd.DataFrame, selection: Dict[str, Any]) -> Dict[str, Any]:
    charts = {}

    # Scatter
    sc = selection.get("scatter")
    if sc and sc.get("x") and sc.get("y"):
        x_col, y_col = sc["x"], sc["y"]
        # Coerce to numeric where possible
        x_ser = pd.to_numeric(df[x_col], errors="coerce")
        y_ser = pd.to_numeric(df[y_col], errors="coerce")
        pairs = [(x, y) for x, y in zip(x_ser.tolist(), y_ser.tolist()) if not (pd.isna(x) or pd.isna(y))]
        if pairs:
            # sample to reasonable size
            sampled = _sample_for_scatter([p[0] for p in pairs], [p[1] for p in pairs])
            points = []
            for xv, yv in sampled:
                try:
                    points.append({"x": float(xv), "y": float(yv)})
                except Exception:
                    continue
            if points:
                charts["scatter"] = {"label": f"{y_col} vs {x_col}", "points": points, "x": x_col, "y": y_col}

    # Bar
    bar_sel = selection.get("bar")
    if bar_sel:
        cat_col = bar_sel.get("cat")
        agg = bar_sel.get("agg")
        if cat_col:
            # if agg present use mean, else counts
            if agg:
                try:
                    grouped = df.groupby(cat_col)[agg].mean().sort_values(ascending=False).head(20)
                    labels = [str(l) for l in grouped.index.tolist()]
                    values = [None if pd.isna(v) else float(v) for v in grouped.values.tolist()]
                    charts["bar"] = {"label": f"Average {agg} by {cat_col}", "labels": labels, "values": values}
                except Exception:
                    pass
            else:
                counts = df[cat_col].value_counts().head(20)
                labels = [str(l) for l in counts.index.tolist()]
                values = [int(v) for v in counts.values.tolist()]
                if values:
                    charts["bar"] = {"label": f"Counts of {cat_col}", "labels": labels, "values": values}
        elif agg:
            col = agg
            vals = pd.to_numeric(df[col], errors="coerce").dropna()
            if len(vals) > 0:
                hist, bin_edges = np.histogram(vals, bins=10)
                labels = [f"{float(bin_edges[i]):.2f} - {float(bin_edges[i+1]):.2f}" for i in range(len(bin_edges)-1)]
                charts["bar"] = {"label": f"Distribution of {col}", "labels": labels, "values": hist.tolist()}

    # Histogram
    hist_sel = selection.get("histogram")
    if hist_sel and hist_sel.get("col"):
        col = hist_sel["col"]
        vals = pd.to_numeric(df[col], errors="coerce").dropna()
        if len(vals) > 0:
            hist, edges = np.histogram(vals, bins=10)
            labels = [f"{edges[i]:.2f}-{edges[i+1]:.2f}" for i in range(len(edges)-1)]
            charts["histogram"] = {"label": f"Histogram of {col}", "labels": labels, "values": hist.tolist()}

    # Area
    area_sel = selection.get("area")
    if area_sel:
        if area_sel.get("time") and area_sel.get("value"):
            time_col = area_sel["time"]
            val_col = area_sel["value"]
            try:
                # Use already-coerced datetime column when possible
                if pd.api.types.is_datetime64_any_dtype(df[time_col]):
                    times = df[time_col]
                else:
                    times = pd.to_datetime(df[time_col], errors="coerce")
                tmp = df.assign(_time=times)
                grouped = tmp.groupby(pd.Grouper(key="_time", freq="D"))[val_col].sum().fillna(0)
                if len(grouped) > 0:
                    labels = [ts.strftime("%Y-%m-%d") for ts in grouped.index]
                    values = [float(v) for v in grouped.values.tolist()]
                    charts["area"] = {"label": f"{val_col} over time ({time_col})", "labels": labels, "values": values}
            except Exception:
                charts["area"] = None
        elif area_sel.get("value"):
            col = area_sel["value"]
            vals = pd.to_numeric(df[col], errors="coerce").dropna()
            if len(vals) > 0:
                vals_sorted = vals.sort_values()
                labels = [str(i) for i in range(len(vals_sorted))]
                values = vals_sorted.cumsum().tolist()
                charts["area"] = {"label": f"Cumulative {col}", "labels": labels, "values": [float(v) for v in values]}

    # Ensure JSON-serializable and only include keys that have data
    return make_serializable(charts)


def call_llm_for_insights(summary: Dict[str, Any], max_tokens: int = 512) -> str:
    try:
        system_prompt = (
            "You are a data analyst assistant. Given the dataset summary and statistics, "
            "produce a short list of 4-6 actionable KPIs (name and calculation), and 4-6 analytical insights "
            "about trends, outliers, correlations, and recommended next steps. Keep answers concise and numbered."
        )

        user_content = (
            "Dataset summary (JSON):\n\n" + json.dumps(make_serializable(summary), indent=2) + "\n\n"
            "Return JSON with two keys: 'kpis' (array of objects with name and formula/value hint) and "
            "'insights' (array of short textual insights). Keep each KPI and insight short (1-2 sentences)."
        )

        response = client.chat.completions.create(
            model=DEPLOYMENT,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            max_completion_tokens=max_tokens,
            temperature=1,
        )

        assistant_msg = response.choices[0].message.content
        return assistant_msg
    except ClientAuthenticationError as e:
        return f"LLM authentication error: {str(e)}"
    except HttpResponseError as e:
        return f"LLM service error: {str(e)}"
    except Exception as e:
        return f"LLM call failed: {str(e)}\n{traceback.format_exc()}"


def analyze_csv_bytes(csv_bytes: bytes) -> Dict[str, Any]:
    try:
        df = pd.read_csv(io.BytesIO(csv_bytes))
    except Exception:
        try:
            df = pd.read_csv(io.BytesIO(csv_bytes), engine="python")
        except Exception as ex:
            raise ValueError(f"Failed to parse CSV: {ex}") from ex

    # basic preprocessing: try to parse datetimes strictly and coerce numeric candidates
    try:
        # Strict detection coerces columns in-place when successful
        _ = detect_datetime_cols_strict(df)
    except Exception:
        # don't fail whole analysis on detection problems
        pass

    # Also coerce numeric-like object columns
    try:
        _ = detect_more_numeric_cols(df)
    except Exception:
        pass

    summary = dataframe_summary(df)
    selection = choose_columns_for_charts(df)
    charts = build_chart_data(df, selection)
    llm_insights = call_llm_for_insights(summary)

    quick_kpis = []
    quick_kpis.append({"name": "Total Rows", "value": int(summary.get("rows", 0))})
    quick_kpis.append({"name": "Total Columns", "value": int(summary.get("columns", 0))})

    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    for c in numeric_cols[:5]:
        try:
            mean_val = df[c].mean()
            quick_kpis.append({"name": f"Mean of {c}", "value": None if pd.isna(mean_val) else float(mean_val)})
        except Exception:
            continue

    result = {
        "quick_kpis": make_serializable(quick_kpis),
        "llm_insights": llm_insights,
        "charts": charts,
        "summary": summary,
        "selection": selection,  # include selection so frontend can show which columns were used
    }

    return make_serializable(result)